<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>

<!-- Sicurezza: Se non c'è un ordine passato dalla Servlet, rimanda agli ordini -->
<c:if test="${empty ordine}">
    <c:redirect url="area-utente.jsp#ordini" />
</c:if>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ricevuta Ordine #${ordine.id} | SolidifyLab</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/global.css">
    <!-- File CSS specifico per la fattura -->
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/fattura.css">
</head>
<body class="invoice-body">

    <div class="invoice-container">
        
        <!-- ELEMENTI NON STAMPABILI (Menu e bottoni superiori) -->
        <div class="no-print invoice-actions">
            <a href="${pageContext.request.contextPath}/area-utente.jsp#ordini" class="btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> Torna agli Ordini
            </a>
            <!-- Tasto magico per la stampa nativa -->
            <button type="button" class="btn-primary" onclick="window.print()">
                <i class="fa-solid fa-print"></i> Stampa Ricevuta
            </button>
        </div>

        <!-- ================= INTESTAZIONE FATTURA ================= -->
        <header class="invoice-header">
            <div class="invoice-brand">
                <img src="${pageContext.request.contextPath}/images/logo-prova1.png" alt="SolidifyLab Logo" class="invoice-logo">
                <h2>SolidifyLab</h2>
                <p>Via dell'Università, 1 - 00100 Roma (RM)<br>P.IVA: 01234567890<br>Email: info@solidifylab.com</p>
            </div>
            
            <div class="invoice-meta">
                <h1>RICEVUTA DI ACQUISTO</h1>
                <p><strong>N. Ordine:</strong> #${ordine.id}</p>
                <p><strong>Data Ordine:</strong> ${ordine.data}</p>
                <p><strong>Metodo di Pagamento:</strong> ${ordine.metodoPagamento}</p>
            </div>
        </header>

        <hr class="invoice-divider">

        <!-- ================= DATI CLIENTE ================= -->
        <section class="invoice-customer">
            <h3>Intestato a:</h3>
            <p><strong>${ordine.utente.nome} ${ordine.utente.cognome}</strong></p>
            <p>Email: ${ordine.utente.email}</p>
            
            <!-- Mostra l'indirizzo solo se l'ordine lo prevede (es. Stampe 3D) -->
            <c:if test="${not empty ordine.indirizzoSpedizione}">
                <p>Indirizzo di Spedizione:<br>${ordine.indirizzoSpedizione}</p>
            </c:if>
        </section>

        <!-- ================= TABELLA PRODOTTI ================= -->
        <section class="invoice-items">
            <table class="invoice-table">
                <thead>
                    <tr>
                        <th>Descrizione Prodotto</th>
                        <th class="text-center">Quantità</th>
                        <th class="text-right">Prezzo Unitario</th>
                        <th class="text-right">Totale</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="item" items="${ordine.prodotti}">
                        <tr>
                            <td>
                                <strong>${item.prodotto.nome}</strong><br>
                                <small class="text-muted">Categoria: ${item.prodotto.categoria}</small>
                            </td>
                            <td class="text-center">${item.quantita}</td>
                            <td class="text-right">€ <fmt:formatNumber value="${item.prodotto.prezzo}" pattern="#,##0.00"/></td>
                            <td class="text-right">€ <fmt:formatNumber value="${item.prodotto.prezzo * item.quantita}" pattern="#,##0.00"/></td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </section>

        <!-- ================= TOTALI ================= -->
        <section class="invoice-totals">
            <div class="totals-box">
                <div class="totals-row">
                    <span>Subtotale:</span>
                    <span>€ <fmt:formatNumber value="${ordine.subtotale}" pattern="#,##0.00"/></span>
                </div>
                
                <c:if test="${ordine.speseSpedizione > 0}">
                    <div class="totals-row">
                        <span>Spese di Spedizione:</span>
                        <span>€ <fmt:formatNumber value="${ordine.speseSpedizione}" pattern="#,##0.00"/></span>
                    </div>
                </c:if>
                
                <div class="totals-row totals-final">
                    <strong>TOTALE PAGATO:</strong>
                    <strong>€ <fmt:formatNumber value="${ordine.totale}" pattern="#,##0.00"/></strong>
                </div>
            </div>
        </section>

        <!-- ================= FOOTER FATTURA ================= -->
        <footer class="invoice-footer">
            <p>Grazie per il tuo acquisto su SolidifyLab!</p>
            <p><small>Questo documento è generato elettronicamente ed è valido ai fini della garanzia.</small></p>
        </footer>

    </div>

</body>
</html>